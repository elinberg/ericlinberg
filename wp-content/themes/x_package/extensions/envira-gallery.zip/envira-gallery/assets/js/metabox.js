/**
* You'll need to use CodeKit or similar, as this file is a placeholder to combine
* the following JS files into min/metabox-min.js:
*
* - gallery-helper.js
* - gallery-types.js
* - media-delete.js
* - media-edit.js
* - media-insert.js
* - media-manage.js
* - media-upload.js
*/