CKEDITOR.plugins.setLang('lineheight','de', {
    title: 'Zeilenhöhe'
} );
