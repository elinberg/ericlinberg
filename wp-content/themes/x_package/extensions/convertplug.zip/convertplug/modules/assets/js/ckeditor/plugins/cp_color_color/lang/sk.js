﻿/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'sk', {
	title: 'UI výber farby',
	preview: 'Živý náhľad',
	config: 'Vložte tento reťazec do vášho config.js súboru',
	predefined: 'Preddefinované sady farieb'
} );
